# Preventa Distribuidores del Castillo — v0.1.0

Primera base funcional del proyecto Android.

## Módulos incluidos
- Dashboard con meta, avance, clientes y efectividad.
- Clientes con organización por día.
- Preventa con productos y presentaciones Unidad/Docena/Caja.
- Cálculo de subtotal, descuento y total.
- Consolidado de productos para picking.
- Configuración inicial de impresión térmica 58/80 mm.
- Arquitectura preparada para almacenamiento local/offline.

## Próxima etapa
1. Room con entidades completas de clientes, productos, pedidos y créditos.
2. Persistencia de pedidos.
3. Bluetooth ESC/POS real para impresoras 58/80 mm.
4. Importación de catálogo.
5. Usuarios y sincronización.
6. Reportes y copias de seguridad.

## Compilación
Abrir el proyecto en Android Studio y ejecutar:
./gradlew assembleDebug

El APK quedará en:
app/build/outputs/apk/debug/app-debug.apk
