package com.distribuidoresdelcastillo.preventa

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

data class Client(val id:Int, val name:String, val day:String, val discount:Double, val credit:Double, val balance:Double)
data class Product(val id:Int, val name:String, val unit:Double, val dozen:Double, val box:Double)
data class CartItem(val product:Product, val presentation:String, val qty:Int, val price:Double)

private val sampleClients = listOf(
    Client(1,"Pulpería La Bendición","Lunes",5.0,10000.0,3200.0),
    Client(2,"Pulpería El Progreso","Martes",3.0,8000.0,1200.0),
    Client(3,"Distribuidora San José","Miércoles",7.0,15000.0,6500.0),
    Client(4,"Pulpería La Esquina","Jueves",5.0,7000.0,0.0),
    Client(5,"Mini Súper Central","Viernes",10.0,20000.0,9000.0)
)
private val sampleProducts = listOf(
    Product(1,"Coca Cola 3 L",75.0,840.0,1680.0),
    Product(2,"Arroz 5 lb",150.0,1650.0,3300.0),
    Product(3,"Aceite 1 L",90.0,990.0,1980.0),
    Product(4,"Frijoles 1 lb",55.0,600.0,1200.0),
    Product(5,"Big Cola 3 L",55.0,600.0,1200.0),
    Product(6,"Leche Eskimo",65.0,720.0,1440.0)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PreventaApp() }
    }
}

@Composable
fun PreventaApp() {
    var screen by remember { mutableStateOf("Inicio") }
    var selectedClient by remember { mutableStateOf<Client?>(null) }
    var cart by remember { mutableStateOf(listOf<CartItem>()) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1565C0),
            secondary = Color(0xFF2E7D32),
            surface = Color(0xFFF7F9FC)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Preventa", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        if (screen != "Inicio") IconButton({ screen="Inicio" }) {
                            Icon(Icons.Default.ArrowBack, "Atrás")
                        }
                    },
                    actions = {
                        IconButton({ screen="Configuración" }) {
                            Icon(Icons.Default.Settings, "Configuración")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavItem("Inicio", Icons.Default.Home, screen) { screen="Inicio" }
                    NavItem("Clientes", Icons.Default.People, screen) { screen="Clientes" }
                    NavItem("Preventa", Icons.Default.ShoppingCart, screen) { screen="Preventa" }
                    NavItem("Consolidado", Icons.Default.List, screen) { screen="Consolidado" }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when(screen) {
                    "Inicio" -> Dashboard(onPreventa={screen="Preventa"})
                    "Clientes" -> ClientsScreen(onSelect={ selectedClient=it; screen="Preventa" })
                    "Preventa" -> SalesScreen(selectedClient, cart, {cart=it}, {screen="Consolidado"})
                    "Consolidado" -> ConsolidatedScreen(cart)
                    "Configuración" -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun NavItem(label:String, icon: androidx.compose.ui.graphics.vector.ImageVector, current:String, go:()->Unit) {
    NavigationBarItem(selected=current==label, onClick=go, icon={Icon(icon,label)}, label={Text(label)})
}

@Composable
fun Dashboard(onPreventa:()->Unit) {
    val meta=50000.0
    val venta=32500.0
    val avance=(venta/meta*100).coerceAtMost(100.0)
    val programados=40
    val pedidos=31
    val efectividad=pedidos.toDouble()/programados*100

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item {
            Text("Resumen del día", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
            Text("Sábado 03 de octubre de 2026", color=Color.Gray)
        }
        item {
            Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                    Text("Avance de meta", fontWeight=FontWeight.Bold)
                    Box(Modifier.padding(16.dp).size(150.dp).clip(CircleShape).background(Color(0xFFE3F2FD)), contentAlignment=Alignment.Center) {
                        Column(horizontalAlignment=Alignment.CenterHorizontally) {
                            Text("${avance.roundToInt()}%", fontSize=32.sp, fontWeight=FontWeight.Bold, color=MaterialTheme.colorScheme.primary)
                            Text("de C$ ${meta.toInt()}")
                        }
                    }
                    LinearProgressIndicator({ (avance/100).toFloat() }, Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Text("Venta acumulada: C$ ${"%,.2f".format(venta)}", fontWeight=FontWeight.SemiBold)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                MetricCard("Clientes", "$programados", Modifier.weight(1f))
                MetricCard("Con pedido", "$pedidos", Modifier.weight(1f))
                MetricCard("Efectividad", "${efectividad.roundToInt()}%", Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Avance de clientes", fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("$pedidos de $programados clientes con pedido")
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator({ (efectividad/100).toFloat() }, Modifier.fillMaxWidth(), color=MaterialTheme.colorScheme.secondary)
                }
            }
        }
        item {
            Button(onClick=onPreventa, Modifier.fillMaxWidth().height(52.dp)) {
                Icon(Icons.Default.AddShoppingCart, null)
                Spacer(Modifier.width(8.dp))
                Text("Iniciar preventa")
            }
        }
    }
}

@Composable
fun MetricCard(title:String, value:String, modifier:Modifier=Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp), horizontalAlignment=Alignment.CenterHorizontally) {
            Text(value, fontSize=22.sp, fontWeight=FontWeight.Bold)
            Text(title, fontSize=12.sp, color=Color.Gray)
        }
    }
}

@Composable
fun ClientsScreen(onSelect:(Client)->Unit) {
    var day by remember { mutableStateOf("Todos") }
    val days=listOf("Todos","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado")
    val clients=if(day=="Todos") sampleClients else sampleClients.filter{it.day==day}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Gestión de clientes", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(6.dp)) {
            days.forEach { d -> FilterChip(selected=day==d,onClick={day=d},label={Text(d)}) }
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(clients) { c ->
                Card(Modifier.fillMaxWidth().clickable{onSelect(c)}) {
                    Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFE3F2FD)), contentAlignment=Alignment.Center) {
                            Text(c.name.take(1), fontWeight=FontWeight.Bold)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.name, fontWeight=FontWeight.Bold)
                            Text("${c.day} • Descuento ${c.discount}%")
                            Text("Crédito disponible: C$ ${"%,.2f".format(c.credit-c.balance)}", fontSize=12.sp, color=Color.Gray)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
    }
}

@Composable
fun SalesScreen(client:Client?, cart:List<CartItem>, setCart:(List<CartItem>)->Unit, finish:()->Unit) {
    var presentation by remember { mutableStateOf("Unidad") }
    var product by remember { mutableStateOf(sampleProducts.first()) }
    var qty by remember { mutableStateOf(1) }
    var discount by remember { mutableStateOf(client?.discount ?: 0.0) }
    val price=when(presentation) {"Docena"->product.dozen;"Caja"->product.box;else->product.unit}
    val subtotal=cart.sumOf{it.qty*it.price}
    val discountAmount=subtotal*discount/100
    val total=subtotal-discountAmount

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Nueva preventa", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text(client?.name ?: "Seleccione un cliente en Gestión de clientes", color=MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(14.dp))
        Text("Producto", fontWeight=FontWeight.Bold)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
            OutlinedTextField(product.name, {}, readOnly=true, modifier=Modifier.fillMaxWidth().menuAnchor(), trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)})
            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                sampleProducts.forEach { p -> DropdownMenuItem(text={Text(p.name)},onClick={product=p;expanded=false}) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Presentación", fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            listOf("Unidad","Docena","Caja").forEach { p -> FilterChip(selected=presentation==p,onClick={presentation=p},label={Text(p)}) }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(qty.toString(), { qty=it.filter(Char::isDigit).toIntOrNull()?.coerceAtLeast(1) ?: 1 }, label={Text("Cantidad")}, modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Button(onClick={setCart(cart+CartItem(product,presentation,qty,price))}, Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Agregar al pedido — C$ ${"%,.2f".format(qty*price)}")
        }
        Spacer(Modifier.height(16.dp))
        Text("Detalle del pedido", fontWeight=FontWeight.Bold)
        cart.forEach { item ->
            Card(Modifier.fillMaxWidth().padding(vertical=3.dp)) {
                Row(Modifier.padding(10.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.product.name, fontWeight=FontWeight.SemiBold)
                        Text("${item.qty} ${item.presentation} × C$ ${"%,.2f".format(item.price)}")
                    }
                    Text("C$ ${"%,.2f".format(item.qty*item.price)}")
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(discount.toString(), {discount=it.toDoubleOrNull()?.coerceIn(0.0,100.0)?:0.0}, label={Text("Descuento %")}, modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        SummaryRow("Subtotal", subtotal)
        SummaryRow("Descuento", -discountAmount)
        SummaryRow("TOTAL", total, true)
        Spacer(Modifier.height(12.dp))
        Button(onClick=finish, enabled=cart.isNotEmpty(), Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(8.dp)); Text("PONER EN FIRME")
        }
        OutlinedButton(onClick={setCart(emptyList())}, Modifier.fillMaxWidth()) { Text("Vaciar pedido") }
    }
}

@Composable
fun SummaryRow(label:String, value:Double, bold:Boolean=false) {
    Row(Modifier.fillMaxWidth().padding(vertical=3.dp), horizontalArrangement=Arrangement.SpaceBetween) {
        Text(label, fontWeight=if(bold) FontWeight.Bold else FontWeight.Normal)
        Text("C$ ${"%,.2f".format(value)}", fontWeight=if(bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
fun ConsolidatedScreen(cart:List<CartItem>) {
    val consolidated=cart.groupBy{it.product.name}.mapValues{entry->entry.value.sumOf{it.qty}}
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Consolidado / Picking", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Text("Resumen de productos prevendidos", color=Color.Gray)
        Spacer(Modifier.height(12.dp))
        if(consolidated.isEmpty()) {
            Card(Modifier.fillMaxWidth()) { Text("Aún no hay productos consolidados.", Modifier.padding(20.dp)) }
        } else {
            LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                items(consolidated.entries.toList()) { e ->
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                            Text(e.key, Modifier.weight(1f), fontWeight=FontWeight.SemiBold)
                            Text("${e.value}", fontSize=20.sp, fontWeight=FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick={},Modifier.fillMaxWidth()) { Icon(Icons.Default.Print,null); Spacer(Modifier.width(8.dp)); Text("Imprimir picking list") }
        }
    }
}

@Composable
fun SettingsScreen() {
    var width by remember { mutableStateOf("80 mm") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Configuración", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Impresora térmica", fontWeight=FontWeight.Bold)
                Text("Preparada para conexión Bluetooth ESC/POS")
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    listOf("58 mm","80 mm").forEach { p -> FilterChip(selected=width==p,onClick={width=p},label={Text(p)}) }
                }
                Spacer(Modifier.height(8.dp))
                Text("Ancho seleccionado: $width", color=Color.Gray)
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Operación offline", fontWeight=FontWeight.Bold)
                Text("Los datos y pedidos se diseñarán para permanecer disponibles sin conexión.")
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Versión", fontWeight=FontWeight.Bold)
                Text("Preventa Distribuidores del Castillo 0.1.0")
            }
        }
    }
}
